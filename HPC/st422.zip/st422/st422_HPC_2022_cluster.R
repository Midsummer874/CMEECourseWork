# CMEE 2022 HPC exercises R code pro forma

rm(list=ls()) 
graphics.off()

source("/rds/general/user/st422/home/HPC/st422_HPC_2022_main.R")


iter <- as.numeric(Sys.getenv("PBS_ARRAY_INDEX")) #set the pbs index to the iter

#set my speciation_rate
speciation_rate = 0.23 

#Everyone will use the same values for community size in their simulations(500,1000,2500,5000)
if (iter %in% 1:25){
  size = 500
}else if (iter %in% 26:50){
  size = 1000
}else if (iter %in% 51:75){
  size = 2500
}else if (iter %in% 76:100){
  size = 5000
}

wall_time = 11.5*60 #11.5 hour to minutes

Output_name = paste0("./SimulationOutput_",
                     iter,".rda")

#You need to control the random number seeds so that each parallel simulation takes place with a different seed. 
set.seed(iter) #So your function should set the random number seed as iter

cluster_run(speciation_rate, size, wall_time, interval_rich = 1, interval_oct = size/10, burn_in_generations = 8*size, 
            output_file_name = Output_name)
